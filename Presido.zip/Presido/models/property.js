const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
  place: String,
  area: String,
  bedrooms: Number,
  bathrooms: Number,
  nearby: String
});

module.exports = mongoose.model('Property', propertySchema);
