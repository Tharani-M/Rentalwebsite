const redirectForm = document.getElementById('redirect-form');
const pageContent = document.getElementById('page-content');

redirectForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const selectedPage = document.querySelector('input[name="page"]:checked').value;
    fetchPage(selectedPage);
});

function fetchPage(page) {
    fetch(`${page}.html`)
        .then(response => {
            if (response.ok) {
                return response.text();
            }
            throw new Error('Page not found');
        })
        .then(data => {
            pageContent.innerHTML = data;
        })
        .catch(error => {
            console.error('Error fetching page:', error.message);
            pageContent.innerHTML = `<p>Error: Page not found</p>`;
        });
}
