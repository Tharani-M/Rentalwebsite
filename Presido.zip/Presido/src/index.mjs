import express from 'express';
import path from 'path';
import mongoose from 'mongoose';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const loggingMiddileware = (request,response,next)=>{
    console.log('${request.method} - ${request.url}');
    next();
}


const PORT = process.env.PORT || 3000;

mongoose.connect('mongodb://localhost:27017/mydb',{
    useNewUrlParser : true,
    useUnifiedTopology:true
})
.then(()=>{
   console.log('MongoDB connected');
})
.catch((error)=>{
    console.log('server is running on http://localhost:${PORT}')
});

const mockUsers = [{ First_Name : "afdv1",
Last_Name : "adjv1",
Email : "afv1",
Phone_number : 1111111133}];

app.get('/api/users',(request,response)=>{
    response.status(200).send(mockUsers);
    return response.send(mockUsers);
});

app.post("/api/users",loggingMiddileware,(req,res)=>{
    // const {body} = request;
    // const newUser = {body};
    // mockUsers.push(newUser);
    // // console.log(request.body)
    // return response.status(201).send(newUser);
    const { first_name, last_name, email, phone } = req.body;

    // Convert form data to JSON
    const formData = {
        first_name,
        last_name,
        email,
        phone
    };

    // Log the form data to the console
    console.log('Form Data:', formData);

    // Respond with JSON
    const reply = res.json({
        message: 'Form submitted successfully!',
        data: formData
    });
    return res.status(201).send(reply).redirect('http://127.0.0.1:3001/src/next-page.html');
});

app.listen(PORT,()=>{
    console.log('Running on port'+PORT);
});

